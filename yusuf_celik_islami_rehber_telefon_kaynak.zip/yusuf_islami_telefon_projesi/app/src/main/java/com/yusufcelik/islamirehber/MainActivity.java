package com.yusufcelik.islamirehber;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private final int green = Color.rgb(18, 61, 50);
    private final int gold = Color.rgb(179, 138, 69);
    private final int cream = Color.rgb(250, 247, 239);
    private LinearLayout content;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(12, 12, 12, 12);
        return t;
    }

    private void showHome() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(cream);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(20, 24, 20, 24);
        scroll.addView(content);
        TextView title = text("☾  YUSUF ÇELİK\nİSLAMİ REHBER", 25, Color.WHITE, true);
        title.setBackgroundColor(green);
        content.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView subtitle = text("İlim, huzur ve güzel hatırlayış", 15, green, false);
        content.addView(subtitle);
        addButton("İslam'ın Şartları", v -> showInfo("İSLAM'IN ŞARTLARI", "1. Kelime-i şehadet getirmek\n\n2. Namaz kılmak\n\n3. Oruç tutmak\n\n4. Zekât vermek\n\n5. Hacca gitmek"));
        addButton("İmanın Şartları", v -> showInfo("İMANIN ŞARTLARI", "1. Allah'a iman\n\n2. Meleklerine iman\n\n3. Kitaplarına iman\n\n4. Peygamberlerine iman\n\n5. Ahiret gününe iman\n\n6. Kadere, hayır ve şerrin Allah'tan olduğuna iman"));
        addButton("Dualar", v -> showInfo("DUALAR", "Besmele: Bismillahirrahmanirrahim\n\nŞükür: Elhamdülillah\n\nTesbih: Sübhanallah\n\nTekbir: Allahu ekber\n\nTevhid: La ilahe illallah"));
        addButton("Zikirmatik", v -> showZikir());
        addButton("Namaz Vakitleri", v -> showInfo("NAMAZ VAKİTLERİ", "Bu başlangıç sürümünde canlı namaz vakitleri henüz eklenmedi. Sonraki sürümde konum ve hesaplama yöntemi eklenebilir."));
        addButton("Kıble Pusulası", v -> showInfo("KIBLE PUSULASI", "Bu başlangıç sürümünde sensörlü kıble pusulası henüz eklenmedi. Sonraki sürümde konum ve cihaz sensörleriyle geliştirilebilir."));
        TextView footer = text("Allah ilminizi ve ibadetlerinizi kabul etsin.", 13, green, false);
        content.addView(footer);
        setContentView(scroll);
    }

    private void addButton(String label, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false);
        b.setTextSize(17); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(green));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 7, 0, 7);
        content.addView(b, p); b.setOnClickListener(listener);
    }

    private void showInfo(String heading, String body) {
        content.removeAllViews();
        TextView h = text(heading, 22, Color.WHITE, true); h.setBackgroundColor(green);
        content.addView(h, new LinearLayout.LayoutParams(-1, -2));
        TextView t = text(body, 18, green, false); t.setGravity(Gravity.START); t.setPadding(8, 24, 8, 24);
        content.addView(t, new LinearLayout.LayoutParams(-1, -2));
        addButton("Ana Sayfaya Dön", v -> showHome());
    }

    private int count = 0;
    private void showZikir() {
        content.removeAllViews();
        TextView h = text("ZİKİRMATİK", 22, Color.WHITE, true); h.setBackgroundColor(green);
        content.addView(h, new LinearLayout.LayoutParams(-1, -2));
        TextView number = text(String.valueOf(count), 48, green, true);
        content.addView(number, new LinearLayout.LayoutParams(-1, 180));
        addButton("+1 Zikir", v -> { count++; number.setText(String.valueOf(count)); });
        addButton("Sıfırla", v -> { count = 0; number.setText("0"); });
        addButton("Ana Sayfaya Dön", v -> showHome());
    }
}
