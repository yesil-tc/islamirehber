# Yusuf Çelik İslami Rehber — telefonda APK derleme başlangıç paketi

Bu, ilk ve sade Android uygulama kaynak projesidir. Google Colab, GitHub ve web sitesine uygulama yayımlama gerektirmez. APK'yı cihaz üzerinde derleyen bir Android IDE gerekir.

## Önerilen yol
1. Android telefonunda Google Play'i açıp **AIDE – Android IDE** uygulamasını ara. Yayıncıyı, son güncelleme tarihini ve cihaz uyumluluğunu kontrol et; ben bu oturumda mağaza durumunu doğrulayamıyorum.
2. ZIP dosyasını telefonuna indir ve Dosyalar uygulamasından çıkart.
3. AIDE içinde Android/Gradle proje açma veya içe aktarma seçeneği varsa `YusufCelikIslamiRehber` klasörünü aç. İçe aktarma desteklenmiyorsa yeni bir Java Android projesi oluşturup `MainActivity.java`, manifest ve tema dosyalarını ilgili yerlere kopyala.
4. IDE'nin istediği Android SDK/Gradle bileşenlerini indir. Bu ilk kurulumda internet ve yeterli depolama gerekebilir.
5. Build/Run ya da Build APK seçeneğini kullan. Menü isimleri uygulama sürümüne göre değişebilir.
6. APK oluşursa IDE'nin gösterdiği dosya konumundan aç ve Android'in izin verdiği şekilde yükle.

## Bu sürümde
- Ana menü
- İslam'ın şartları ve imanın şartları
- Kısa dua/zikir metinleri
- Basit zikirmatik
- Namaz vakitleri ve kıble pusulası için sonraki sürüm açıklamaları

## Henüz olmayanlar
- Canlı namaz vakitleri
- Arka planda kesin saatli ezan bildirimi/sesi
- Sensör kullanan gerçek kıble pusulası

Bunlar ilk APK başarıyla derlendikten sonra eklenecek. APK oluşturma sonucu cihazdaki IDE, Android sürümü ve indirdiği derleme araçlarına bağlıdır.
